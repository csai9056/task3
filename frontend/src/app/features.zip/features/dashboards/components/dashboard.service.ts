import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { environment } from 'src/environments/environment';
import * as xlsx from 'xlsx';
import { jsPDF } from 'jspdf';
@Injectable({
  providedIn: 'root',
})
export class DashboardService {
  dataSource = new Subject<any>();
  // data1 = this.dataSource.asObservable();
  constructor(private http: HttpClient) {}
  data: any;
  onproductdelete(id: number) {
    return this.http.put(`${environment.url}/dash/product/delete`, { id: id });
  }
  getproducts(): Observable<any> {
    return this.http.get(`${environment.url}/dash/product`);
  }
  addproducts(productdata: any) {
    return this.http.post(`${environment.url}/dash/product`, productdata);
  }
  setdata(item: any) {
    this.dataSource.next(item);
    this.data = item;
  }
  ondownloadxl(products: any) {
    const ws = xlsx.utils.json_to_sheet(products?.data);
    const wb = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(wb, ws, 'place');
    xlsx.writeFile(wb, 'dashboard.xlsx');
  }
  ondownloadpdf(item: any) {
    const doc = new jsPDF();
    doc.text('products details', 20, 10);
    let y = 20;
    Object.entries(item).forEach(([key, value]) => {
      doc.text(`${key}: ${value}`, 20, y);
      y += 10;
    });
    doc.save('product.pdf');
  }

  getdata() {
    return this.data;
  }
  editproduct(edit: any) {
    return this.http.put(`${environment.url}/dash/products`, edit);
  }
  getvendors() {
    return this.http.get(`${environment.url}/dash/vendor`);
  }
  getcategories() {
    return this.http.get(`${environment.url}/dash/categories`);
  }
  getProducts1(
    page: number,
    limit: number
  ): Observable<{
    success: string;
    products: any;
    total: number;
    page: number;
    limit: number;
  }> {
    return this.http.get<{
      success: string;
      products: any;
      total: number;
      page: number;
      limit: number;
    }>(`${environment.url}/dash/product?page=${page}&limit=${limit}`);
  }
}
