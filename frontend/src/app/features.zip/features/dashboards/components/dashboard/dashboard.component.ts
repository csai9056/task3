import { HttpClient } from '@angular/common/http';
import { ProductformComponent } from './../productform/productform.component';
import { Component, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';
import { DashboardService } from '../dashboard.service';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  searchTerm: string = '';
  valid = false;
  showCart: boolean = false; // Flag to control which table is shown
  products: any;
  vendorCount: number = 0;

  currentPage: number = 1;
  totalPages: number = 1;
  pageSize: number = 5; // Items per page
  totalitems: number = 0;
  pages: number[] = [];
  // products: any;
  constructor(
    private http: HttpClient,
    private dashservice: DashboardService
  ) {}
  ngOnInit(): void {
    // this.dashservice.getproducts().subscribe((data) => {
    //   this.products = data;
    //   console.log(data);
    // });
    this.fetchPage(this.currentPage);
  }
  fetchPage(page: number): void {
    if (page < 1 || (this.totalPages && page > this.totalPages)) return;

    this.dashservice.getProducts1(page, this.pageSize).subscribe({
      next: (data: any) => {
        console.log(data);
        this.products = data;
        this.totalitems = data.total;
        this.currentPage = data.page;
        this.totalPages = Math.ceil(this.totalitems / this.pageSize);
        this.pages = Array.from({ length: this.totalPages }, (_, i) => i + 1);
        console.log(this.pages);
      },
      error: (error: any) => {
        console.error('Error fetching products:', error);
      },
    });
  }

  handleform(productdata: any) {
    if (productdata.status === 'Available') productdata.status = '1';
    else productdata.status = '0';
    this.dashservice.addproducts(productdata).subscribe((data) => {
      console.log(data);
    });
  }
  ondownload() {
    this.dashservice.ondownloadxl(this.products);
  }
  onpdfdownload(item: any) {
    this.dashservice.ondownloadpdf(item);
  }
  onproductdelete(id: number) {
    const modal = document.getElementById('confirmAction');
    modal?.addEventListener('click', () => {
      console.log(id);
      this.dashservice.onproductdelete(id).subscribe((data: any) => {
        console.log(data);
        alert(data.message);
      });
    });
  }
  onproductedit(item: any) {
    this.dashservice.setdata(item);
  }
  editform(edit: any) {
    this.dashservice.editproduct(edit).subscribe((data) => {
      alert(data);
    });
  }
}
