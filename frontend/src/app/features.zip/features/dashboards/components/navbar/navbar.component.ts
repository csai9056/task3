import { Component, OnInit } from '@angular/core';
import { AwsService } from '../../services/aws.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css'],
})
export class NavbarComponent implements OnInit {
  bootstrap: any;
  user: any = {};
  selectedFile: File | null = null;
  fileUrl: string = '';
  constructor(
    private aws: AwsService,
    private router: Router,
    private Http: HttpClient
  ) {}
  jwtToken: string = ' ';
  ngOnInit(): void {
    if (sessionStorage) {
      const jwtToken = sessionStorage.getItem('access_token');
      if (jwtToken) {
        const payload = jwtToken.split('.')[1];
        this.user = JSON.parse(atob(payload));
        console.log(this.user);
        this.getUserInfo(this.user.userId);
      } else {
        console.error('Token not found .');
      }
    }
  }
  getUserInfo(id: number): void {
    this.Http.post(`${environment.url}/dash/userdata`, { id: id }).subscribe(
      (data1) => {
        this.user = data1;
        this.user = this.user.data;
        console.log(data1);
      }
    );
  }

  handleFileUpload(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      this.selectedFile = input.files[0];
      console.log('File selected:', this.selectedFile);
    }
  }

  onUpload(): void {
    if (this.selectedFile) {
      const fileName = this.selectedFile.name;
      const fileType = this.selectedFile.type;
      console.log('befors pre', this.user.user_id);
      this.aws
        .getPresignedUrl(fileName, fileType, this.user.user_id)
        .subscribe({
          next: (response) => {
            const { presignedUrl, fileName, userId } = response;
            this.uploadToS3(presignedUrl, fileName, userId);
          },
          error: (error) => {
            console.error('Error getting presigned URL:', error);
          },
        });
    }
  }
  uploadToS3(presignedUrl: string, fileName: string, userId: string): void {
    if (this.selectedFile) {
      console.log(presignedUrl);
      this.aws.uploadFileToS3(presignedUrl, this.selectedFile).subscribe({
        next: () => {
          console.log('File successful uploaded in S3');
          console.log('before' + this.user.user_id);
          this.aws
            .updateProfilePic(this.user.user_id, fileName, presignedUrl)
            .subscribe({
              next: (response) => {
                // console.log(response.message);
                this.closeModal();
              },
              error: (error) => {
                console.error('Error updating profile picture:', error);
              },
            });
        },
        error: (error) => {
          console.error('Error uploading file:', error);
        },
      });
    }
  }

  closeModal() {
    const modalElement = document.getElementById('uploadModal');
  }

  onLogout() {
    sessionStorage.clear();
    this.router.navigate(['/auth/login']);
  }
}
