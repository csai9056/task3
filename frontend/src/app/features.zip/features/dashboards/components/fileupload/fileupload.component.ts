import { Component, OnInit } from '@angular/core';
import { AwsService } from '../../services/aws.service';
@Component({
  selector: 'app-fileupload',
  templateUrl: './fileupload.component.html',
  styleUrls: ['./fileupload.component.css'],
})
export class FileuploadComponent implements OnInit {
  data: any;
  constructor(private aws: AwsService) {}
  ngOnInit(): void {
    this.aws.getobjects().subscribe((data: any) => {
      console.log(data.objects);
      this.data = data.objects;
    });
  }
  selectedFile: File | null = null;
  handleFileUpload(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      this.selectedFile = input.files[0];
      console.log('File selected:', this.selectedFile);
    }
  }
  onUpload(): void {
    if (this.selectedFile) {
      const fileName = this.selectedFile.name;
      const fileType = this.selectedFile.type;
      const flodername = 'files';
      // console.log('befors pre', this.user.user_id);
      this.aws.getPresignedUrl(fileName, fileType, '-1').subscribe({
        next: (response) => {
          const { presignedUrl, fileName, userId } = response;
          this.uploadToS3(presignedUrl, fileName, userId);
        },
        error: (error) => {
          console.error('Error getting presigned URL:', error);
        },
      });
    }
  }
  uploadToS3(presignedUrl: string, fileName: string, userId: string): void {
    if (this.selectedFile) {
      console.log(presignedUrl);
      this.aws.uploadFileToS3(presignedUrl, this.selectedFile).subscribe({
        next: () => {
          console.log('File successful uploaded in S3');
        },
        error: (error) => {
          console.error('Error uploading file:', error);
        },
      });
    }
  }
}
